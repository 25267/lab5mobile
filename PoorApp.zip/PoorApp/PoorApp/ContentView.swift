//
//  ContentView.swift
//  PoorApp
//
//  Created by Zhanibek on 14.10.2021.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        NavigationView {
            
            ZStack {
                Color("Background 5")
                
                Image("poor")
                    .renderingMode(.template)
                    .foregroundColor(.white)
            }
            .edgesIgnoringSafeArea(.bottom)
            .navigationTitle("I Am Poor")
            .navigationBarTitleDisplayMode(.inline)
            
           
                
              
                
            
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
            .preferredColorScheme(.dark)
.previewInterfaceOrientation(.portraitUpsideDown)
    }
}
