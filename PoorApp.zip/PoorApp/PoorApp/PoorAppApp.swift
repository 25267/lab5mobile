//
//  PoorAppApp.swift
//  PoorApp
//
//  Created by Zhanibek on 14.10.2021.
//

import SwiftUI

@main
struct PoorAppApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
